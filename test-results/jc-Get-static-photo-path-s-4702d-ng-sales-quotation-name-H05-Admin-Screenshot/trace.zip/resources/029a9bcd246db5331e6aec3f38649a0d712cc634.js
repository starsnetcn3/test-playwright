(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[50],{

/***/ "./json/user-list-data_3.json":
/*!************************************!*\
  !*** ./json/user-list-data_3.json ***!
  \************************************/
/*! exports provided: users, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"users\\\":[{\\\"user_id\\\":\\\"U001\\\",\\\"username\\\":\\\"admin.zhang\\\",\\\"role\\\":\\\"Administrator\\\",\\\"email\\\":\\\"admin.zhang@example.com\\\",\\\"last_login\\\":\\\"2025-01-10 14:30:00\\\",\\\"status\\\":\\\"Active\\\"},{\\\"user_id\\\":\\\"U002\\\",\\\"username\\\":\\\"staff.wang\\\",\\\"role\\\":\\\"Salesperson\\\",\\\"email\\\":\\\"sales.wang@example.com\\\",\\\"last_login\\\":\\\"2025-02-15 13:45:00\\\",\\\"status\\\":\\\"Active\\\"},{\\\"user_id\\\":\\\"U003\\\",\\\"username\\\":\\\"admin.li\\\",\\\"role\\\":\\\"Administrator\\\",\\\"email\\\":\\\"admin.li@example.com\\\",\\\"last_login\\\":\\\"2025-03-15 12:20:00\\\",\\\"status\\\":\\\"Inactive\\\"}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL3VzZXItbGlzdC1kYXRhXzMuanNvbi5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./json/user-list-data_3.json\n");

/***/ })

}]);