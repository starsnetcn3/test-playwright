(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[56],{

/***/ "./json/quotation-data_1.json":
/*!************************************!*\
  !*** ./json/quotation-data_1.json ***!
  \************************************/
/*! exports provided: quotations, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"quotations\\\":[{\\\"quotation_no\\\":\\\"QT2025004\\\",\\\"customer\\\":\\\"Global Solutions Inc\\\",\\\"created_date\\\":\\\"2025-03-05\\\",\\\"valid_until\\\":\\\"2025-04-05\\\",\\\"total_amount\\\":28750,\\\"status\\\":\\\"approved\\\"},{\\\"quotation_no\\\":\\\"QT2025005\\\",\\\"customer\\\":\\\"Tech Innovations LLC\\\",\\\"created_date\\\":\\\"2025-03-06\\\",\\\"valid_until\\\":\\\"2025-04-06\\\",\\\"total_amount\\\":15400,\\\"status\\\":\\\"pending\\\"},{\\\"quotation_no\\\":\\\"QT2025006\\\",\\\"customer\\\":\\\"Sunrise Enterprises\\\",\\\"created_date\\\":\\\"2025-03-07\\\",\\\"valid_until\\\":\\\"2025-04-07\\\",\\\"total_amount\\\":41200,\\\"status\\\":\\\"draft\\\"}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL3F1b3RhdGlvbi1kYXRhXzEuanNvbi5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./json/quotation-data_1.json\n");

/***/ })

}]);