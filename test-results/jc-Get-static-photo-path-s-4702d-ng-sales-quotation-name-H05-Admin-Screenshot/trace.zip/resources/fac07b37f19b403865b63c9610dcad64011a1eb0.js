(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[61],{

/***/ "./json/quotation-details-data_3.json":
/*!********************************************!*\
  !*** ./json/quotation-details-data_3.json ***!
  \********************************************/
/*! exports provided: quotation, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"quotation\\\":{\\\"quotation_no\\\":\\\"QT2025002\\\",\\\"created_date\\\":\\\"2025-03-02T10:30:00Z\\\",\\\"valid_until\\\":\\\"2025-04-02\\\",\\\"status\\\":\\\"pending\\\",\\\"sales_person\\\":\\\"John Smith\\\",\\\"remarks\\\":\\\"Special discount applied for bulk purchase\\\",\\\"customer\\\":{\\\"company\\\":\\\"XYZ Trading Co\\\",\\\"contact_person\\\":\\\"David Lee\\\",\\\"email\\\":\\\"david.lee@xyz-trading.com\\\",\\\"phone\\\":\\\"+852 2345 6789\\\"},\\\"items\\\":[{\\\"product_code\\\":\\\"PRD001\\\",\\\"name\\\":\\\"Product A\\\",\\\"quantity\\\":10,\\\"unit_price\\\":1000,\\\"discount\\\":50,\\\"total\\\":9500},{\\\"product_code\\\":\\\"PRD002\\\",\\\"name\\\":\\\"Product B\\\",\\\"quantity\\\":5,\\\"unit_price\\\":2000,\\\"discount\\\":100,\\\"total\\\":9000}],\\\"calculations\\\":{\\\"subtotal\\\":18500,\\\"discount\\\":750,\\\"tax\\\":0,\\\"total\\\":17750}}}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL3F1b3RhdGlvbi1kZXRhaWxzLWRhdGFfMy5qc29uLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./json/quotation-details-data_3.json\n");

/***/ })

}]);