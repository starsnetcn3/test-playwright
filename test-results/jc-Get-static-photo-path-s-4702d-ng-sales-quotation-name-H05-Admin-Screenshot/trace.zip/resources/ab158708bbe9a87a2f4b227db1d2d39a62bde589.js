(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[52],{

/***/ "./json/user-permission-data_2.json":
/*!******************************************!*\
  !*** ./json/user-permission-data_2.json ***!
  \******************************************/
/*! exports provided: permissions, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"permissions\\\":[{\\\"permission_id\\\":\\\"P004\\\",\\\"permission_name\\\":\\\"Inventory Control\\\",\\\"description\\\":\\\"Manage inventory levels and stock movements\\\",\\\"type\\\":\\\"System\\\",\\\"status\\\":\\\"Active\\\"},{\\\"permission_id\\\":\\\"P005\\\",\\\"permission_name\\\":\\\"Financial Reporting\\\",\\\"description\\\":\\\"Access and generate financial reports\\\",\\\"type\\\":\\\"System\\\",\\\"status\\\":\\\"Inactive\\\"},{\\\"permission_id\\\":\\\"P006\\\",\\\"permission_name\\\":\\\"Dashboard Customization\\\",\\\"description\\\":\\\"Customize personal dashboard views\\\",\\\"type\\\":\\\"Custom\\\",\\\"status\\\":\\\"Active\\\"}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL3VzZXItcGVybWlzc2lvbi1kYXRhXzIuanNvbi5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./json/user-permission-data_2.json\n");

/***/ })

}]);