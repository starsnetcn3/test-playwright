(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[47],{

/***/ "./json/login-history-data_3.json":
/*!****************************************!*\
  !*** ./json/login-history-data_3.json ***!
  \****************************************/
/*! exports provided: history, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"history\\\":[{\\\"login_id\\\":\\\"L001\\\",\\\"user\\\":\\\"admin.zhang\\\",\\\"ip_address\\\":\\\"192.168.1.100\\\",\\\"device\\\":\\\"Chrome\\\",\\\"os\\\":\\\"Windows\\\",\\\"login_time\\\":\\\"2025-01-12 14:30:00\\\",\\\"status\\\":\\\"Active\\\"},{\\\"login_id\\\":\\\"L002\\\",\\\"user\\\":\\\"sales.wang\\\",\\\"ip_address\\\":\\\"192.168.1.101\\\",\\\"device\\\":\\\"Safari\\\",\\\"os\\\":\\\"MacOS\\\",\\\"login_time\\\":\\\"2025-02-15 13:45:00\\\",\\\"status\\\":\\\"Success\\\"},{\\\"login_id\\\":\\\"L003\\\",\\\"user\\\":\\\"unknown\\\",\\\"ip_address\\\":\\\"192.168.1.102\\\",\\\"device\\\":\\\"Firefox\\\",\\\"os\\\":\\\"Linux\\\",\\\"login_time\\\":\\\"2025-03-15 13:30:00\\\",\\\"status\\\":\\\"Failed\\\"}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL2xvZ2luLWhpc3RvcnktZGF0YV8zLmpzb24uanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./json/login-history-data_3.json\n");

/***/ })

}]);