(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[44],{

/***/ "./json/agenda-data_3.json":
/*!*********************************!*\
  !*** ./json/agenda-data_3.json ***!
  \*********************************/
/*! exports provided: agenda, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"agenda\\\":[{\\\"agenda_id\\\":\\\"AGD001\\\",\\\"conference\\\":\\\"Annual Strategic Planning Meeting\\\",\\\"topic\\\":\\\"2025 Strategic Objectives\\\",\\\"duration\\\":60,\\\"presenter\\\":\\\"John Smith\\\",\\\"description\\\":\\\"Discuss and determine the main strategic objectives and key performance indicators for 2025\\\",\\\"order\\\":1},{\\\"agenda_id\\\":\\\"AGD002\\\",\\\"conference\\\":\\\"Annual Strategic Planning Meeting\\\",\\\"topic\\\":\\\"Market Analysis Report\\\",\\\"duration\\\":45,\\\"presenter\\\":\\\"Alice Brown\\\",\\\"description\\\":\\\"Analyze current market trends and competitive态势\\\",\\\"order\\\":2},{\\\"agenda_id\\\":\\\"AGD003\\\",\\\"conference\\\":\\\"Annual Strategic Planning Meeting\\\",\\\"topic\\\":\\\"Budget Planning\\\",\\\"duration\\\":30,\\\"presenter\\\":\\\"Bob Wilson\\\",\\\"description\\\":\\\"Create a budget plan for 2025\\\",\\\"order\\\":3}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL2FnZW5kYS1kYXRhXzMuanNvbi5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./json/agenda-data_3.json\n");

/***/ })

}]);