(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[148],{

/***/ "./json/assignments-data_3.json":
/*!**************************************!*\
  !*** ./json/assignments-data_3.json ***!
  \**************************************/
/*! exports provided: project, assignments, available, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"project\\\":{\\\"project_id\\\":\\\"PRJ001\\\",\\\"project_name\\\":\\\"Website Redesign\\\",\\\"description\\\":\\\"Complete redesign of company website with modern UI/UX\\\",\\\"start_date\\\":\\\"2025-01-01\\\",\\\"end_date\\\":\\\"2025-03-30\\\",\\\"status\\\":\\\"active\\\"},\\\"assignments\\\":{\\\"departments\\\":[{\\\"dept_id\\\":\\\"DEP001\\\",\\\"name\\\":\\\"IT Department\\\",\\\"manager\\\":\\\"John Smith\\\",\\\"assigned_date\\\":\\\"2025-03-01\\\",\\\"status\\\":\\\"active\\\"},{\\\"dept_id\\\":\\\"DEP002\\\",\\\"name\\\":\\\"Design Department\\\",\\\"manager\\\":\\\"Sarah Chen\\\",\\\"assigned_date\\\":\\\"2025-03-01\\\",\\\"status\\\":\\\"active\\\"}],\\\"staff\\\":[{\\\"staff_id\\\":\\\"STF001\\\",\\\"name\\\":\\\"Alice Brown\\\",\\\"department\\\":\\\"IT Department\\\",\\\"position\\\":\\\"Senior Developer\\\",\\\"role\\\":\\\"Team Lead\\\",\\\"assigned_date\\\":\\\"2025-03-01\\\",\\\"status\\\":\\\"active\\\"},{\\\"staff_id\\\":\\\"STF002\\\",\\\"name\\\":\\\"Bob Wilson\\\",\\\"department\\\":\\\"Design Department\\\",\\\"position\\\":\\\"UI Designer\\\",\\\"role\\\":\\\"Designer\\\",\\\"assigned_date\\\":\\\"2025-03-01\\\",\\\"status\\\":\\\"active\\\"}]},\\\"available\\\":{\\\"departments\\\":[{\\\"dept_id\\\":\\\"DEP003\\\",\\\"name\\\":\\\"Marketing Department\\\",\\\"manager\\\":\\\"Mike Johnson\\\"}],\\\"staff\\\":[{\\\"staff_id\\\":\\\"STF003\\\",\\\"name\\\":\\\"Carol Davis\\\",\\\"department\\\":\\\"IT Department\\\",\\\"position\\\":\\\"Developer\\\"}]}}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL2Fzc2lnbm1lbnRzLWRhdGFfMy5qc29uLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./json/assignments-data_3.json\n");

/***/ })

}]);