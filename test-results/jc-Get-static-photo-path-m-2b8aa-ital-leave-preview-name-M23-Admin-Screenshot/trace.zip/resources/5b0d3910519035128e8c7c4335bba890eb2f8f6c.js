(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[213],{

/***/ "./json/inventory-data_3.json":
/*!************************************!*\
  !*** ./json/inventory-data_3.json ***!
  \************************************/
/*! exports provided: statistics, categories, inventory, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"statistics\\\":{\\\"total_items\\\":156,\\\"in_stock\\\":120,\\\"low_stock\\\":25,\\\"out_of_stock\\\":11},\\\"categories\\\":[{\\\"id\\\":\\\"CAT001\\\",\\\"name\\\":\\\"Electronics\\\"},{\\\"id\\\":\\\"CAT002\\\",\\\"name\\\":\\\"Office Supplies\\\"},{\\\"id\\\":\\\"CAT003\\\",\\\"name\\\":\\\"Furniture\\\"}],\\\"inventory\\\":[{\\\"id\\\":\\\"INV001\\\",\\\"sku\\\":\\\"EL-001\\\",\\\"name\\\":\\\"LED Monitor 24\\\\\\\"\\\",\\\"category\\\":\\\"Electronics\\\",\\\"barcode\\\":\\\"8901234567890\\\",\\\"barcode_image\\\":\\\"/images/barcodes/8901234567890.png\\\",\\\"quantity\\\":45,\\\"unit\\\":\\\"pcs\\\",\\\"stock_status\\\":\\\"In Stock\\\",\\\"last_updated\\\":\\\"2024-03-25\\\"},{\\\"id\\\":\\\"INV002\\\",\\\"sku\\\":\\\"OS-001\\\",\\\"name\\\":\\\"A4 Paper 500 Sheets\\\",\\\"category\\\":\\\"Office Supplies\\\",\\\"barcode\\\":\\\"8901234567891\\\",\\\"barcode_image\\\":\\\"/images/barcodes/8901234567891.png\\\",\\\"quantity\\\":5,\\\"unit\\\":\\\"box\\\",\\\"stock_status\\\":\\\"Low Stock\\\",\\\"last_updated\\\":\\\"2024-03-24\\\"},{\\\"id\\\":\\\"INV003\\\",\\\"sku\\\":\\\"FN-001\\\",\\\"name\\\":\\\"Office Chair\\\",\\\"category\\\":\\\"Furniture\\\",\\\"barcode\\\":\\\"8901234567892\\\",\\\"barcode_image\\\":\\\"/images/barcodes/8901234567892.png\\\",\\\"quantity\\\":0,\\\"unit\\\":\\\"pcs\\\",\\\"stock_status\\\":\\\"Out of Stock\\\",\\\"last_updated\\\":\\\"2024-03-23\\\"}]}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qc29uL2ludmVudG9yeS1kYXRhXzMuanNvbi5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./json/inventory-data_3.json\n");

/***/ })

}]);